package com.example.demo;

import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {
//	@Bean
//	@LoadBalanced
//	RestTemplate restTemplate() {
//		return new RestTemplate();
//	}
}
