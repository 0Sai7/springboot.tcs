package com.example.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.booking.dto.BookingDto;
import com.example.booking.entity.Booking;
import com.example.booking.repository.BookingRepository;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    public BookingDto createBooking(BookingDto bookingDto) {
        Booking booking = new Booking();
        booking.setMovieId(bookingDto.getMovieId());
        booking.setUserId(bookingDto.getUserId());
        booking.setSeats(bookingDto.getSeats());

        Booking savedBooking = bookingRepository.save(booking);
        return new BookingDto(savedBooking.getBookingId(), savedBooking.getMovieId(), savedBooking.getUserId(), savedBooking.getSeats());
    }
}
