package com.example.movie_service.dto;

public class MovieDto {

    private int movieId;
    private String name;
   
	public MovieDto(int movieId, String name, String genre) {
		super();
		this.movieId = movieId;
		this.name = name;
		this.genre = genre;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	private String genre;

    // Constructor, Getters, and Setters
}
