package com.example.booking.service;

import com.example.booking.dto.BookingDto;
import com.example.booking.feign.MovieFeignClient;
import com.example.booking.feign.UserFeignClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

    @Autowired
    private MovieFeignClient movieFeignClient;

    @Autowired
    private UserFeignClient userFeignClient;

    public BookingDto createBooking(BookingDto bookingDto) {
        // Call Movie Service to get movie info
        String movieName = movieFeignClient.getMovieById(bookingDto.getMovieId()).getName();
        // Call User Service to get user info
        String userName = userFeignClient.getUserById(bookingDto.getUserId()).getName();

        // Process booking logic here...
        return new BookingDto(bookingDto.getBookingId(), bookingDto.getMovieId(), bookingDto.getUserId(), bookingDto.getSeats());
    }
}
