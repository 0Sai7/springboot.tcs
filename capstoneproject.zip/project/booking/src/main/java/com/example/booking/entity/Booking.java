package com.example.booking.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Booking {

    @Id
    private int bookingId;
    public Booking(int bookingId, int movieId, int userId, int seats) {
		super();
		this.bookingId = bookingId;
		this.movieId = movieId;
		this.userId = userId;
		this.seats = seats;
	}
	public Booking() {
		// TODO Auto-generated constructor stub
	}
	private int movieId;
    public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	private int userId;
    private int seats;

    // Getters and Setters
}
