package com.example.booking.feign;

import com.example.movie_service.dto.MovieDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "movie-service")
public interface MovieFeignClient {

    @GetMapping("/movies")
    MovieDto getMovieById(@RequestParam("id") int id);
}
