package com.example.booking.dto;

public class BookingDto {

    public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public BookingDto(int bookingId, int movieId, int userId, int seats) {
		super();
		this.bookingId = bookingId;
		this.movieId = movieId;
		this.userId = userId;
		this.seats = seats;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	private int bookingId;
    private int movieId;
    private int userId;
    private int seats;

    // Constructor, Getters, and Setters
}
