package com.example.movie_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.movie_service.dto.MovieDto;
import com.example.movie_service.entity.Movie;
import com.example.movie_service.repository.MovieRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MovieService {

    @Autowired
    private MovieRepository movieRepository;

    public List<MovieDto> getAllMovies() {
        List<Movie> movies = movieRepository.findAll();
        return movies.stream()
                     .map(movie -> new MovieDto(movie.getMovieId(), movie.getName(), movie.getGenre()))
                     .collect(Collectors.toList());
    }
}
